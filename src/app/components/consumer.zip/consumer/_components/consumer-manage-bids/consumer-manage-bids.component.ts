import { Component, OnInit } from '@angular/core';
import { ProjectsService } from 'src/app/components/services/projects.service';
import { MatDialog } from '@angular/material';
import { BidProfessionalDialogBoxComponent } from 'src/app/components/landing/bidprofessionaldialogbox/bidprofessionaldialogbox.component';
import { tr, de } from 'date-fns/locale';
import { BidMessageDialogBoxComponent } from 'src/app/components/landing/bidmessagedialogbox/bidmessagedialogbox.component';
import { BidListboxComponent } from 'src/app/components/landing/bid-listbox/bid-listbox.component';
import { BidProfileComponent } from 'src/app/components/landing/bid-profile/bid-profile.component';


@Component({
  selector: 'xb-consumer-manage-bids',
  templateUrl: './consumer-manage-bids.component.html',
  styleUrls: ['./consumer-manage-bids.component.scss']
})
export class ConsumerManageBidsComponent implements OnInit {
  isGridView = false;
  elements: any;
  bidelements: any;
  currencySymbol: any = '$';
  val: number = 0;
  show: boolean = true;
  isDesc: boolean = false;
  column: string = 'providerFirstName';
  direction: number; totalcount: any;
  constructor(public dialog: MatDialog, private _projectsService: ProjectsService) { localStorage.setItem('isPost', 'false'); }

  ngOnInit() {
    this._projectsService.getbiddata().subscribe(res => {
      console.log(res);
      this.elements = res.results;
      this._projectsService.getProjectBid(this.elements[0].id).subscribe(res => {
        this.bidelements = res.results;
        this.totalcount = res.totalCount;
        //this.accordin();
      });
    });

  }
  accordin() {
    var acc = document.getElementsByClassName("accordion");
    var i;
    for (i = 0; i < acc.length; i++) {
      // acc[i].addEventListener("click", function () {
      acc[i].classList.toggle("active");
      // this.classList.toggle("active");
      // var panel = this.nextElementSibling;
      // if (panel.style.display === "block") {
      //   panel.style.display = "none";
      // } else {
      //   panel.style.display = "block";
      // }
      // });
    }
  }
  sort(property) {
    this.isDesc = !this.isDesc; //change the direction 
    this.column = property;
    this.direction = this.isDesc ? 1 : -1;
  };
  onprofessionalPopUp() {
    let dialogRef = this.dialog.open(BidProfessionalDialogBoxComponent, {
    });
  }
  loadProjectBid(id, i) {
    this.bidelements = null;
    this.show = !this.show;
    this._projectsService.getProjectBid(id).subscribe(res => {
      this.val = i;
      this.bidelements = res.results;
      this.totalcount = res.totalCount;
      //this.assignCss(i);
    });
  }
 
  onmszPopUp(projectId, providerId) {
    let dialogRef = this.dialog.open(BidMessageDialogBoxComponent, {
      data: {
        projectId: projectId,
        providerId: providerId
      }
    });
  }

  onListPopUp(projectId) {
    let dialogRef = this.dialog.open(BidListboxComponent, {

      data: {
        projectId: projectId
      }
    });
  }

  openDetailDialogBox(be): void {
    this.dialog.open(BidProfileComponent, {
      data: be
    });
  }
}

