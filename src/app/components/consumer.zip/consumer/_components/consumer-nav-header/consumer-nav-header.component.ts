import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'xb-consumer-nav-header',
  templateUrl: './consumer-nav-header.component.html',
  styleUrls: ['./consumer-nav-header.component.scss']
})
export class ConsumerNavHeaderComponent implements OnInit {
  isGridView = false;
  isPost = false;
  constructor() { this.isPost = Boolean(localStorage.getItem('isPost'));
  console.log(this.isPost);}
  ngOnInit() {
    
  }
}
