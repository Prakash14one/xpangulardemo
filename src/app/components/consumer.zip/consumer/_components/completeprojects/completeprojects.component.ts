import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'xb-completeprojects',
  templateUrl: './completeprojects.component.html',
  styleUrls: ['./completeprojects.component.scss']
})
export class CompleteprojectsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
