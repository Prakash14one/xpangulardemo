import { Component, OnInit } from '@angular/core';
import { ProjectsService } from '../../../services/projects.service';

@Component({
  selector: 'xb-consumer-post',
  templateUrl: './consumer-post.component.html',
  styleUrls: ['./consumer-post.component.scss']
})
export class ConsumerPostComponent implements OnInit {

  isGridView = false;

  myPosts: any = [];

  constructor(private readonly _projectsService: ProjectsService) {

    this._projectsService.getConsumerProjects(1).subscribe( result => {
      console.log(result);
      this.myPosts = result.results;
    });

  }

  ngOnInit() {
    localStorage.setItem('isPost','false');
  }
}
