import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'xb-consumer-calendar',
  templateUrl: './consumer-calendar.component.html',
  styleUrls: ['./consumer-calendar.component.scss']
})
export class ConsumerCalendarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
