import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { MatSelectModule, MatInputModule } from '@angular/material';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { ConsumerCalendarComponent } from './_components/consumer-calendar/consumer-calendar.component';
import { ConsumerComponent } from './consumer.component';
import { ConsumerManageBidsComponent } from './_components/consumer-manage-bids/consumer-manage-bids.component';
import { ConsumerNavHeaderComponent } from './_components/consumer-nav-header/consumer-nav-header.component';
import { ConsumerPostComponent } from './_components/consumer-post/consumer-post.component';
import { CompleteprojectsComponent } from './_components/completeprojects/completeprojects.component';


//import { CalendarPageModule } from '../calendar-page/calendar-page.module';
import { CoreModule } from './../../core/core.module';
import { SharedModule } from './../../shared/shared.module';
import { ConsumerManagePostsComponent } from './_components/consumer-manage-posts/consumer-manage-posts.component';
import { ConsumerEnrollmentsComponent } from './_components/consumer-enrollments/consumer-enrollments.component';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { ConsumerPostCardComponent } from './_components/consumer-post-card/consumer-post-card.component';
import { ConsumerResolutionCenterComponent } from './_components/consumer-resolution-center/consumer-resolution-center.component';
import { SortingPipe } from 'src/app/sorting.pipe';

@NgModule({
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    CommonModule,
    RouterModule,
    MatSelectModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    //CalendarPageModule,
    CoreModule,
    SharedModule,
    NgCircleProgressModule.forRoot({
      // set defaults here
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: "#78C000",
      innerStrokeColor: "#C7E596",
      animationDuration: 300,
  })
   ],

  declarations: [
    ConsumerCalendarComponent,
    ConsumerComponent,
    ConsumerManageBidsComponent,
    ConsumerManagePostsComponent,
    ConsumerNavHeaderComponent,
    ConsumerPostComponent,
    ConsumerEnrollmentsComponent,
    ConsumerPostCardComponent,
    ConsumerResolutionCenterComponent,
    SortingPipe,
    CompleteprojectsComponent
  ]
})
export class ConsumerModule {}
